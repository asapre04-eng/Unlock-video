Unlock Video Player v2
1. App install karke open karein.
2. Add videos (multiple) se videos choose karein. Picker mein jis order mein select karenge, wahi playback sequence hoga.
3. Enable Unlock Detection se Accessibility Service ON karein.
4. Display OFF -> ON -> phone unlock: har baar agla video 10 seconds chalega; last ke baad pehla repeat hoga.
5. Apps open/switch karne par playback trigger nahi hona chahiye.
Note: Fullscreen/cutout behavior Android/OriginOS par device-dependent hai. Build artifact is not a Play-Store-verified release.
