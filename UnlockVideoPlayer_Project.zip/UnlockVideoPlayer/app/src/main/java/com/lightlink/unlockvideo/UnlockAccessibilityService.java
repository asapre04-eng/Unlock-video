package com.lightlink.unlockvideo;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;

public class UnlockAccessibilityService extends AccessibilityService implements TextureView.SurfaceTextureListener {
    private WindowManager wm;
    private FrameLayout overlay;
    private TextureView texture;
    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Video can run only after a real screen-off -> screen-on -> unlock sequence.
    private boolean screenWasOff = false;
    private boolean waitingForUnlock = false;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;

            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                screenWasOff = true;
                waitingForUnlock = false;
                removeVideo();
            } else if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                if (screenWasOff) {
                    waitingForUnlock = true;
                    screenWasOff = false;
                }
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(screenReceiver, filter);
            }
            receiverRegistered = true;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !waitingForUnlock || overlay != null) return;
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;

        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null && !km.isKeyguardLocked()) {
            // Clear the flag before starting playback so app/window changes cannot retrigger it.
            waitingForUnlock = false;
            showVideo();
        }
    }

    private void showVideo() {
        try {
            if (wm == null || overlay != null) return;

            overlay = new FrameLayout(this);
            texture = new TextureView(this);
            texture.setSurfaceTextureListener(this);
            overlay.addView(texture, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            );
            lp.gravity = Gravity.TOP | Gravity.START;
            wm.addView(overlay, lp);
            handler.postDelayed(this::removeVideo, 10_000);
        } catch (Exception e) {
            removeVideo();
        }
    }

    @Override
    public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int width, int height) {
        try {
            player = new MediaPlayer();
            android.content.res.AssetFileDescriptor afd = getAssets().openFd("unlock.mp4");
            try {
                player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            } finally {
                afd.close();
            }
            player.setSurface(new Surface(st));
            player.setOnPreparedListener(mp -> {
                if (overlay != null) mp.start();
            });
            player.setOnCompletionListener(mp -> removeVideo());
            player.setOnErrorListener((mp, what, extra) -> {
                removeVideo();
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            removeVideo();
        }
    }

    @Override public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h) {}
    @Override public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st) { return true; }
    @Override public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st) {}

    private void removeVideo() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
            overlay = null;
        }
        texture = null;
    }

    @Override
    public void onInterrupt() {
        removeVideo();
    }

    @Override
    public void onDestroy() {
        removeVideo();
        if (receiverRegistered) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onDestroy();
    }
}
