package com.lightlink.unlockvideo;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import java.util.ArrayList;

public class UnlockAccessibilityService extends AccessibilityService implements TextureView.SurfaceTextureListener {
    private static final String PREFS = "unlock_player";
    private static final String KEY_URIS = "video_uris";
    private WindowManager wm;
    private FrameLayout overlay;
    private TextureView texture;
    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    // A proximity-sensor screen-off during a call must NOT arm playback.
    // Arm only when Android confirms that the keyguard actually became locked.
    private boolean screenWasOff = false;
    private boolean screenWasLocked = false;
    private boolean waitingForUnlock = false;
    private boolean receiverRegistered = false;
    private final Runnable confirmKeyguardLocked = () -> {
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        screenWasLocked = screenWasOff && km != null && km.isKeyguardLocked();
    };

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                screenWasOff = true;
                screenWasLocked = false;
                waitingForUnlock = false;
                removeVideo();
                handler.removeCallbacks(confirmKeyguardLocked);
                // Let the lockscreen state settle. Proximity-off during calls
                // leaves the keyguard unlocked, so it will not arm playback.
                handler.postDelayed(confirmKeyguardLocked, 350);
            } else if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                handler.removeCallbacks(confirmKeyguardLocked);
                waitingForUnlock = screenWasOff && screenWasLocked;
                screenWasOff = false;
                screenWasLocked = false;
            }
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_EXPORTED);
            else registerReceiver(screenReceiver, filter);
            receiverRegistered = true;
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !waitingForUnlock || overlay != null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return;
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null && !km.isKeyguardLocked()) {
            waitingForUnlock = false;
            showVideo();
        }
    }

    private void showVideo() {
        try {
            if (wm == null || overlay != null) return;
            overlay = new FrameLayout(this);
            texture = new TextureView(this);
            texture.setSurfaceTextureListener(this);
            overlay.addView(texture, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
            );
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(overlay, lp);
            overlay.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
            handler.postDelayed(this::removeVideo, 10_000);
        } catch (Exception e) {
            removeVideo();
        }
    }

    private Uri takeNextVideoUri() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = prefs.getString(KEY_URIS, "");
        if (raw == null || raw.trim().isEmpty()) return null;
        String[] items = raw.split("\n");
        ArrayList<String> uris = new ArrayList<>();
        for (String item : items) if (item != null && !item.trim().isEmpty()) uris.add(item.trim());
        if (uris.isEmpty()) return null;
        int index = prefs.getInt("next_index", 0);
        if (index < 0 || index >= uris.size()) index = 0;
        Uri result = Uri.parse(uris.get(index));
        prefs.edit().putInt("next_index", (index + 1) % uris.size()).apply();
        return result;
    }

    @Override public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int width, int height) {
        try {
            player = new MediaPlayer();
            Uri chosen = takeNextVideoUri();
            if (chosen != null) {
                player.setDataSource(this, chosen);
            } else {
                android.content.res.AssetFileDescriptor afd = getAssets().openFd("unlock.mp4");
                try { player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength()); }
                finally { afd.close(); }
            }
            player.setSurface(new Surface(st));
            player.setOnPreparedListener(mp -> {
                if (overlay != null) {
                    mp.setVolume(1f, 1f);
                    mp.start();
                }
            });
            player.setOnCompletionListener(mp -> removeVideo());
            player.setOnErrorListener((mp, what, extra) -> { removeVideo(); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            removeVideo();
        }
    }

    @Override public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h) {}
    @Override public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st) { return true; }
    @Override public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st) {}

    private void removeVideo() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
            overlay = null;
        }
        texture = null;
    }

    @Override public void onInterrupt() { removeVideo(); }

    @Override public void onDestroy() {
        removeVideo();
        if (receiverRegistered) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onDestroy();
    }
}
