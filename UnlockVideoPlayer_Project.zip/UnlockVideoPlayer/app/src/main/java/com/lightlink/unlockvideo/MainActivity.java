package com.lightlink.unlockvideo;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_VIDEOS = 501;
    private static final String PREFS = "unlock_player";
    private static final String KEY_URIS = "video_uris";
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        refreshStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(10, 24, 45));

        TextView title = new TextView(this);
        title.setText("Unlock Video Player");
        title.setTextSize(26);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 12, 0, 22);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Trigger: Display OFF → Display ON → Phone Unlock. Har unlock par list ka agla video 10 seconds chalega. Last video ke baad sequence pehle video se repeat hoga. Apps kholne ya switch karne par video nahi chalega.");
        info.setTextSize(16);
        info.setTextColor(Color.WHITE);
        info.setPadding(0, 8, 0, 20);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button add = new Button(this);
        add.setText("Add videos (multiple)");
        add.setOnClickListener(v -> pickVideos());
        root.addView(add, new LinearLayout.LayoutParams(-1, -2));

        Button clear = new Button(this);
        clear.setText("Clear selected video list");
        clear.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_URIS).putInt("next_index", 0).apply();
            refreshStatus();
        });
        root.addView(clear, new LinearLayout.LayoutParams(-1, -2));

        Button enable = new Button(this);
        enable.setText("Enable Unlock Detection");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(enable, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(14);
        status.setPadding(0, 24, 0, 0);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Full-screen playback: video screen ke top/status bar area tak extend karne ki koshish karega. Device ke display cutout/OriginOS restrictions ke hisaab se halka difference ho sakta hai. Agar custom list khaali hai to bundled unlock.mp4 chalega.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setPadding(0, 18, 0, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void pickVideos() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_VIDEOS);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_VIDEOS || resultCode != RESULT_OK || data == null) return;

        ArrayList<Uri> picked = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) picked.add(clip.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            picked.add(data.getData());
        }

        ArrayList<String> values = new ArrayList<>();
        for (Uri uri : picked) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                values.add(uri.toString());
            } catch (SecurityException ignored) {
                // Some document providers do not support persistable permissions.
            }
        }
        if (!values.isEmpty()) {
            String joined = android.text.TextUtils.join("\n", values);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_URIS, joined)
                .putInt("next_index", 0)
                .apply();
        }
        refreshStatus();
    }

    private void refreshStatus() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URIS, "");
        int count = 0;
        if (saved != null && !saved.trim().isEmpty()) count = saved.split("\n").length;
        if (status != null) status.setText("Selected videos: " + count + (count == 0 ? " (default unlock.mp4 will play)" : "\nSequence: 1 → 2 → 3 → ... → repeat"));
    }
}
