package com.lightlink.unlockvideo;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;

public class MainActivity extends Activity {
 private static final int PICK=501;
 private static final String PREFS="unlock_player", KEY="video_uris";
 private LinearLayout list; private TextView count;
 private final int bg=0xFF08101F, panel=0xFF111D32, panel2=0xFF172743, white=0xFFF2F6FF, muted=0xFF9DAEC7, cyan=0xFF4AD3E7;
 private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 private GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
 private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
 private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  getWindow().setStatusBarColor(bg);
  getWindow().setNavigationBarColor(bg);
  showSplash();
  new Handler(Looper.getMainLooper()).postDelayed(() -> {
   ui();
   refresh();
  }, 3500);
 }
 private void showSplash(){
  LinearLayout splash=new LinearLayout(this);
  splash.setOrientation(LinearLayout.VERTICAL);
  splash.setGravity(Gravity.CENTER);
  splash.setPadding(dp(28),dp(28),dp(28),dp(28));
  splash.setBackgroundColor(bg);
  ImageView mark=new ImageView(this);
  mark.setImageResource(com.lightlink.unlockvideo.R.drawable.brand_logo);
  mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
  splash.addView(mark,new LinearLayout.LayoutParams(dp(250),dp(250)));
  TextView name=txt("UNLOCK",25,white,true);
  name.setGravity(Gravity.CENTER);
  name.setPadding(0,dp(20),0,dp(3));
  splash.addView(name);
  TextView subtitle=txt("VIDEO PLAYER",14,0xFFF5BE5F,true);
  subtitle.setGravity(Gravity.CENTER);
  splash.addView(subtitle);
  TextView tagline=txt("A NEW LOOK EVERY TIME YOU UNLOCK",10,muted,true);
  tagline.setGravity(Gravity.CENTER);
  tagline.setPadding(0,dp(18),0,0);
  splash.addView(tagline);
  setContentView(splash);
 }
 private void ui(){
  ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(bg);
  LinearLayout page=col();page.setPadding(dp(20),dp(18),dp(20),dp(28));scroll.addView(page);
  LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);
  ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.brand_logo);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);logo.setBackground(shape(panel,14,0));brand.addView(logo,new LinearLayout.LayoutParams(dp(52),dp(52)));
  LinearLayout words=col();words.setPadding(dp(12),0,0,0);words.addView(txt("UNLOCK",17,white,true));words.addView(txt("VIDEO PLAYER  •  LIGHTLINK",10,muted,true));brand.addView(words,new LinearLayout.LayoutParams(0,-2,1));
  TextView ver=txt("V8",11,cyan,true);ver.setPadding(dp(12),dp(7),dp(12),dp(7));ver.setBackground(shape(panel2,20,0));brand.addView(ver);page.addView(brand);
  LinearLayout hero=col();hero.setPadding(dp(0),dp(0),dp(0),dp(18));hero.setBackground(shape(panel,24,0));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(22);page.addView(hero,hp);
  ImageView heroArt=new ImageView(this);heroArt.setImageResource(R.drawable.dashboard_hero);heroArt.setScaleType(ImageView.ScaleType.CENTER_CROP);heroArt.setBackground(shape(panel,22,0));hero.addView(heroArt,new LinearLayout.LayoutParams(-1,dp(260)));
  LinearLayout heroText=col();heroText.setPadding(dp(18),dp(18),dp(18),0);hero.addView(heroText);
  heroText.addView(txt("YOUR UNLOCK EXPERIENCE",10,cyan,true));
  TextView headline=txt("A new look,\\nevery time you unlock.",24,white,true);headline.setPadding(0,dp(9),0,dp(7));heroText.addView(headline);
  heroText.addView(txt("Your videos play in sequence every time your screen wakes and you unlock your phone.",13,muted,false));
  LinearLayout stats=new LinearLayout(this);stats.setGravity(Gravity.CENTER_VERTICAL);stats.setPadding(dp(14),dp(12),dp(14),dp(12));stats.setBackground(shape(0xFF0B1628,16,0));LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2);stp.topMargin=dp(15);heroText.addView(stats,stp);
  LinearLayout sw=col();sw.addView(txt("YOUR VIDEO LIBRARY",10,muted,true));count=txt("0 videos",21,white,true);sw.addView(count);stats.addView(sw,new LinearLayout.LayoutParams(0,-2,1));TextView loop=txt("↻",27,0xFFF5BE5F,true);loop.setGravity(Gravity.CENTER);stats.addView(loop,new LinearLayout.LayoutParams(dp(44),dp(44)));
  LinearLayout sec=new LinearLayout(this);sec.setGravity(Gravity.CENTER_VERTICAL);sec.addView(txt("Your playlist",20,white,true),new LinearLayout.LayoutParams(0,-2,1));TextView on=txt("LOOP ON",10,cyan,true);on.setPadding(dp(10),dp(7),dp(10),dp(7));on.setBackground(shape(panel2,20,0));sec.addView(on);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(26);sp.bottomMargin=dp(8);page.addView(sec,sp);
  page.addView(txt("Videos play in this order. Remove any one without deleting the others.",13,muted,false));
  list=col();LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(14);page.addView(list,lp);
  LinearLayout actions=col();actions.setPadding(dp(16),dp(16),dp(16),dp(16));actions.setBackground(shape(panel,20,0));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(22);page.addView(actions,ap);
  Button add=new Button(this);add.setText("+  ADD VIDEOS");add.setTextColor(bg);add.setAllCaps(false);add.setTextSize(14);add.setTypeface(null,Typeface.BOLD);add.setBackground(shape(cyan,14,0));add.setOnClickListener(v->pick());actions.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
  Button enable=new Button(this);enable.setText("SET UP UNLOCK DETECTION");enable.setTextColor(white);enable.setAllCaps(false);enable.setTextSize(13);enable.setBackground(shape(panel2,14,0));enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(50));ep.topMargin=dp(10);actions.addView(enable,ep);
  TextView footer=txt("SCREEN OFF  →  SCREEN ON  →  UNLOCK  →  NEXT VIDEO",10,muted,true);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(22),0,0);page.addView(footer);
  setContentView(scroll);
 }
 private ArrayList<String> getUris(){
  String raw=getSharedPreferences(PREFS,0).getString(KEY,"");
  ArrayList<String>a=new ArrayList<>();
  if(raw==null||raw.trim().isEmpty())return a;
  // Migrate older builds that stored the two-character sequence "\\n" as a separator.
  raw=raw.replace("\\n","\n");
  for(String item:raw.split("\n"))if(!item.trim().isEmpty())a.add(item.trim());
  return a;
 }
 private void save(ArrayList<String>a){
  // Store one URI per real newline so adding a video never overwrites existing entries.
  getSharedPreferences(PREFS,0).edit().putString(KEY,android.text.TextUtils.join("\n",a)).apply();
  refresh();
 }
 private void refresh(){
  if(list==null)return;list.removeAllViews();ArrayList<String>a=getUris();count.setText(a.size()+(a.size()==1?" video":" videos"));
  if(a.isEmpty()){LinearLayout e=col();e.setGravity(Gravity.CENTER);e.setPadding(dp(20),dp(26),dp(20),dp(26));e.setBackground(shape(panel,18,0));TextView plus=txt("＋",30,cyan,true);plus.setGravity(Gravity.CENTER);e.addView(plus);TextView title=txt("Your playlist is empty",16,white,true);title.setPadding(0,dp(8),0,dp(4));e.addView(title);e.addView(txt("Add one or more videos to get started.",13,muted,false));list.addView(e);return;}
  for(int i=0;i<a.size();i++){final int index=i;Uri uri=Uri.parse(a.get(i));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(10),dp(8),dp(10));row.setBackground(shape(panel,16,0));
   ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setBackground(shape(panel2,12,0));Bitmap frame=null;MediaMetadataRetriever retriever=new MediaMetadataRetriever();try{retriever.setDataSource(this,uri);frame=retriever.getFrameAtTime(1000000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);}catch(Exception ignored){}finally{try{retriever.release();}catch(Exception ignored){}}if(frame!=null)thumb.setImageBitmap(frame);else{thumb.setImageResource(R.drawable.brand_logo);thumb.setScaleType(ImageView.ScaleType.CENTER_INSIDE);}LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(76),dp(58));tp.rightMargin=dp(10);row.addView(thumb,tp);
   TextView num=txt(String.format("%02d",i+1),13,cyan,true);num.setGravity(Gravity.CENTER);num.setBackground(shape(panel2,12,0));row.addView(num,new LinearLayout.LayoutParams(dp(42),dp(42)));
   LinearLayout details=col();details.setPadding(dp(12),0,dp(6),0);TextView name=txt(display(uri),13,white,true);name.setMaxLines(2);details.addView(name);details.addView(txt("VIDEO  •  PLAY ORDER "+(i+1),9,muted,true));row.addView(details,new LinearLayout.LayoutParams(0,-2,1));
   Button del=new Button(this);del.setText("Remove");del.setTextSize(10);del.setAllCaps(false);del.setTextColor(0xFFFF9999);del.setBackground(shape(0xFF3E2230,12,0));del.setOnClickListener(v->{ArrayList<String>now=getUris();if(index<now.size()){now.remove(index);save(now);getSharedPreferences(PREFS,0).edit().putInt("next_index",0).apply();Toast.makeText(this,"Video removed",Toast.LENGTH_SHORT).show();}});row.addView(del);
   LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(9);list.addView(row,rp);
  }
 }
 private String display(Uri u){android.database.Cursor c=null;try{c=getContentResolver().query(u,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst()){int n=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(n>=0)return c.getString(n);}}catch(Exception ignored){}finally{if(c!=null)c.close();}String s=u.getLastPathSegment();return s==null?"Selected video":s;}
 private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK);}
 @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r!=PICK||result!=RESULT_OK||data==null)return;ArrayList<Uri>picked=new ArrayList<>();ClipData clip=data.getClipData();if(clip!=null)for(int i=0;i<clip.getItemCount();i++)picked.add(clip.getItemAt(i).getUri());else if(data.getData()!=null)picked.add(data.getData());ArrayList<String>now=getUris();int added=0;for(Uri u:picked){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}String s=u.toString();if(!now.contains(s)){now.add(s);added++;}}save(now);Toast.makeText(this,added+" video(s) added",Toast.LENGTH_SHORT).show();}
}